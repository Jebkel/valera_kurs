<script>
    function setLike(e) {
        e.target.disabled = true;
        const id = e.target.getAttribute('id');
        axios.get('/sanctum/csrf-cookie').then(response => {
            axios.get('/api/user').then(response => {
                axios.post('/api/set_like/' + id).then(response => {
                    console.log(response);
                    e.target.textContent = 'Избранное';
                    alert(response.data.message);

                }).catch(function (error) {
                    // handle error
                    e.target.disabled = false;
                    if (error.response.status === 401) {
                        window.location = "/login";
                    } else {
                        console.log(error);
                        e.target.textContent = 'ERROR';
                    }
                });
            }).catch(function (error) {
                // handle error
                if (error.response.status === 401) {
                    window.location = "/login";
                } else {
                    e.target.disabled = false;
                    console.log(error);
                    e.target.textContent = 'Error';
                }
            });
        });
    }
</script>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('WELlCUM')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.jstable','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jstable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($link->id); ?></td>
                                <td><?php echo e($link->name); ?></td>
                                <td><?php echo e($link->description); ?></td>
                                <td><a href="<?php echo e($link->url_address); ?>" target="_blank"><?php echo e($link->name); ?></a></td>
                                <td>
                                    <?php if(\App\Models\Likes::where('user_id', \Auth::id())->where('links_id', $link->id)->exists()): ?>
                                        <button disabled @click="setLike" id="<?php echo e($link->id); ?>" class="flex items-center hover:border-gray-300 focus:outline-none focus:border-gray-300 transition duration-150 ease-in-out hover:opacity-90 hover:-rotate-3">
                                            Избранное
                                        </button>
                                    <?php else: ?>
                                        <button @click="setLike" id="<?php echo e($link->id); ?>" class="flex items-center hover:border-gray-300 focus:outline-none focus:border-gray-300 transition duration-150 ease-in-out hover:opacity-90 hover:-rotate-3">
                                            Сохранить
                                        </button>
                                    <?php endif; ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\stasc\PhpstormProjects\valera_loh\resources\views/welcome.blade.php ENDPATH**/ ?>