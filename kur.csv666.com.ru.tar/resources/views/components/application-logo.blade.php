<image src="{{ asset('img/sponge.png') }}" :style="styles"></image>
