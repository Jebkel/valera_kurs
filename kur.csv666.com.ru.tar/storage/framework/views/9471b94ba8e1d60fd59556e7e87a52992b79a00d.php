<image src="<?php echo e(asset('img/sponge.png')); ?>" :style="styles"></image>
<?php /**PATH /var/www/kur.csv666.com.ru/resources/views/components/application-logo.blade.php ENDPATH**/ ?>